﻿namespace $safeprojectname$.Models
{
    public class Author
    {
        public int AuthorId { get; set; }
        public string AuthorName { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }
}
